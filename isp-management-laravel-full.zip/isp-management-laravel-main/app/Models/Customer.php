<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Customer extends Authenticatable
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'mikrotik_status', 'mikrotik_uid', 'last_online_at',
        'occupation', 'gender', 'zone_id', 'sub_zone_id',
        'connection_type_id', 'client_type_id', 'protocol_type_id', 'router_id',
        'mac_reseller_id',
        'mac_reseller_zone_id', 'mac_reseller_sub_zone_id', // ── reseller-scoped zone/sub-zone (used only when mac_reseller_id is set) ──
        'mac_reseller_tariff_package_id', // ── reseller-scoped package line (Server/Protocol/Profile), used instead of package_id when mac_reseller_id is set ──
        'billing_status', 'monthly_bill_amount',
        'customer_code', 'name', 'phone', 'email', 'nid_number',
        'nid_photo', 'photo', 'address', 'latitude', 'longitude', 'package_id',
        'agent_id', 'connection_date', 'connection_fee', 'billing_date',
        'expire_date', 'last_payment_date', 'status',
        'ip_address', 'mac_address', 'pppoe_username', 'pppoe_password',
        'remarks', 'created_by', 'advance_balance',
    ];

    protected $casts = [
        'connection_date'  => 'date',
        'expire_date'      => 'date',
        'last_payment_date'=> 'date',
        'last_online_at'   => 'datetime',
        'billing_date'     => 'integer',
        'advance_balance'  => 'decimal:2',
        'connection_fee'   => 'decimal:2',
        'monthly_bill_amount' => 'decimal:2',
    ];

    protected $hidden = [
        'pppoe_password',
    ];

    // ── Relations ──────────────────────────────────────────

    public function package()
    {
        return $this->belongsTo(Package::class);
    }

    // ── Reseller-scoped package line (Server/Protocol/Profile/Rate) — used when mac_reseller_id is set ──
    public function resellerTariffPackage()
    {
        return $this->belongsTo(\App\Models\MacResellerTariffPackage::class, 'mac_reseller_tariff_package_id');
    }

    public function agent()
    {
        return $this->belongsTo(Agent::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function tickets()
    {
        return $this->hasMany(Ticket::class);
    }

    public function supportTickets()
    {
        return $this->hasMany(ClientSupportTicket::class);
    }

    public function smsLogs()
    {
        return $this->hasMany(SmsLog::class);
    }

    // ── Global Zone/SubZone — used for customers created directly by ISP Admin ──
    public function zone()
    {
        return $this->belongsTo(\App\Models\Zone::class);
    }

    public function subZone()
    {
        return $this->belongsTo(\App\Models\SubZone::class);
    }

    // ── Reseller-scoped Zone/SubZone — used for customers created by a MAC Reseller ──
    public function resellerZone()
    {
        return $this->belongsTo(\App\Models\MacResellerZone::class, 'mac_reseller_zone_id');
    }

    public function resellerSubZone()
    {
        return $this->belongsTo(\App\Models\MacResellerSubZone::class, 'mac_reseller_sub_zone_id');
    }

    public function connectionType()
    {
        return $this->belongsTo(\App\Models\ConnectionType::class);
    }

    public function clientType()
    {
        return $this->belongsTo(\App\Models\ClientType::class);
    }

    public function protocolType()
    {
        return $this->belongsTo(\App\Models\ProtocolType::class);
    }

    public function router()
    {
        return $this->belongsTo(\App\Models\MikrotikRouter::class, 'router_id');
    }

   
    public function macReseller()
    {
        return $this->belongsTo(\App\Models\MacReseller::class, 'mac_reseller_id');
    }

    // ── Scopes ─────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeExpired($query)
    {
        return $query->where('status', 'expired');
    }

    public function scopeByArea($query, $area)
    {
        return $query->where('area', $area);
    }

    
    public function scopeForReseller($query, $resellerId)
    {
        return $query->where('mac_reseller_id', $resellerId);
    }

    // ── Helpers ────────────────────────────────────────────

    public static function generateCode(): string
    {
        $prefix = \App\Models\Setting::get('customer_code_prefix', 'ISP');
        $last   = self::withTrashed()->orderByRaw('CAST(SUBSTRING_INDEX(customer_code, "-", -1) AS UNSIGNED) DESC')->first();
        $number = $last ? (intval(substr($last->customer_code, strrpos($last->customer_code, '-') + 1)) + 1) : 1;
        return $prefix . '-' . str_pad($number, 4, '0', STR_PAD_LEFT);
    }

    public function inventoryLedger()
    {
        return $this->hasMany(\App\Models\Inventory\ClientLedger::class, 'client_id');
    }    
}