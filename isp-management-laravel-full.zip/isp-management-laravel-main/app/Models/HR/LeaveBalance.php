<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class LeaveBalance extends Model
{
    //
}
