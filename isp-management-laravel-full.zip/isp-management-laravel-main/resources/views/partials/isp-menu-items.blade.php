{{-- resources/views/partials/isp-menu-items.blade.php
     Recursive sidebar menu renderer — ISP Admin chrome.

     Renders items from config('adminlte.menu'):
       · ['header' => 'LABEL']                 → section label
       · ['text','url','icon']                 → flat link
       · ['text','icon','submenu' => [...]]    → collapsible group (recursive)
     Every item may carry 'can' (string) — checked via Gate.

     Variables:
       $items  — array of menu entries
       $level  — 0 = sidebar root, 1+ = nested inside a submenu
 --}}
@php
    $level = $level ?? 0;

    // permission check (string 'can')
    $canSee = function ($item) {
        if (!isset($item['can'])) return true;
        try {
            return \Illuminate\Support\Facades\Gate::allows($item['can']);
        } catch (\Throwable $e) {
            return false;
        }
    };

    // active url match: exact path or child path
    $urlActive = function ($url) {
        if (empty($url)) return false;
        $path = trim(parse_url($url, PHP_URL_PATH) ?: $url, '/');
        if ($path === '' || $path === '/') return false;
        $path = ltrim($path, '/');
        return request()->is($path) || request()->is($path.'/*');
    };

    // does any child (recursive) resolve active?
    $subtreeActive = function ($subs) use (&$subtreeActive, $canSee, $urlActive) {
        foreach ($subs as $sub) {
            if (!$canSee($sub)) continue;
            if (!empty($sub['url']) && $urlActive($sub['url'])) return true;
            if (!empty($sub['submenu']) && $subtreeActive($sub['submenu'])) return true;
        }
        return false;
    };

    // icon class cleanup: config icons like 'fas fa-fw fa-users' are kept as-is
    $icon = function ($item) {
        $i = $item['icon'] ?? 'far fa-circle';
        return preg_replace('/\s*fa-fw\s*/', ' ', $i) ?: 'far fa-circle';
    };
@endphp

@foreach($items as $item)
    @continue(!$canSee($item))

    @if(isset($item['header']))
        <div class="nav-section">{{ $item['header'] }}</div>

    @elseif(!empty($item['submenu']))
        @php $open = $subtreeActive($item['submenu']); @endphp
        <div class="nav-group {{ $open ? 'open' : '' }}">
            <button type="button"
                    class="isp-nav-item nav-group-toggle {{ $open ? 'active' : '' }}">
                <i class="{{ $icon($item) }}"></i>
                <span>{{ $item['text'] }}</span>
                <i class="fas fa-chevron-down chevron"></i>
            </button>
            <div class="submenu">
                @include('partials.isp-menu-items', ['items' => $item['submenu'], 'level' => $level + 1])
            </div>
        </div>

    @else
        @php $href = $item['url'] ?? '#'; @endphp
        <a href="{{ url($href) }}"
           class="{{ $level === 0 ? 'isp-nav-item' : 'isp-sub-item' }} {{ $level > 1 ? 'nested' : '' }} {{ $urlActive($href) ? 'active' : '' }}">
            <i class="{{ $icon($item) }}"></i>
            <span>{{ $item['text'] }}</span>
        </a>
    @endif
@endforeach
