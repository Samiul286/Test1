{{-- resources/views/super-admin/auth/login.blade.php
     Super Admin login — same client-portal auth design as staff login. --}}
@extends('layouts.isp-auth')

@section('title', 'Super Admin Login')
@section('subtitle', 'Central Control Panel')

@section('auth_content')
    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle" style="margin-top:1px;"></i>
            <span>{{ $errors->first() }}</span>
        </div>
    @endif

    <form action="{{ route('super-admin.login.post') }}" method="POST">
        @csrf

        <div class="form-group">
            <label>ইমেইল / Email</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="super.admin@example.com"
                    value="{{ old('email') }}" required autofocus>
            </div>
        </div>

        <div class="form-group">
            <label>পাসওয়ার্ড / Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="Your password" required>
            </div>
        </div>

        <div class="remember-row" style="display:flex; align-items:center; gap:8px; margin-bottom:1.25rem; font-size:13px; color:#666;">
            <input type="checkbox" name="remember" id="remember" value="1">
            <label for="remember" style="margin:0; text-transform:none; font-size:13px; font-weight:400; color:#666; letter-spacing:0;">আমাকে মনে রাখো</label>
        </div>

        <button type="submit" class="btn-auth">
            <i class="fas fa-user-shield" style="margin-right:6px;"></i> লগইন করুন
        </button>
    </form>

    <div class="hint-box">
        <strong><i class="fas fa-shield-alt"></i> Super Admin Access</strong>
        This is the central control panel for managing ISPs, plans, gateways
        and permissions.
    </div>
@endsection
