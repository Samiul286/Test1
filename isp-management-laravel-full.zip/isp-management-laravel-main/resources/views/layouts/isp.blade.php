{{-- resources/views/layouts/isp.blade.php
     ─────────────────────────────────────────────────────────
     ISP Admin / Staff Portal — Master Layout
     Replicates the Client Self-Service Portal UI/UX
     (resources/views/client/layout.blade.php):

       · Navy topbar  #1a1f36 · 56px · fixed · teal logo box
       · White sidebar · teal active states · left accent
       · Light gray canvas #f4f6f9 · 12px rounded cards
       · Segoe UI typography · FontAwesome 6.4

     Provides the section contract of `adminlte::page`
     (title / content_header / content / css / js) so that views
     previously extending AdminLTE keep working unchanged.

     Optional variables from wrapper layouts:
       $guard — auth guard ('web' | 'super_admin')
     ───────────────────────────────────────────────────────── --}}
@php
    $guard = $guard ?? 'web';
    $authUser  = auth($guard)->user();

    // Tenant DBs carry the settings table; the central (super-admin)
    // DB does not — fall back to the app title when it is unavailable.
    try {
        $brandName = \App\Models\Setting::get('company_name', config('adminlte.title', 'ISP Management'));
    } catch (\Throwable $e) {
        $brandName = config('adminlte.title', 'ISP Management');
    }

    $initial   = strtoupper(mb_substr(trim($brandName), 0, 1)) ?: 'I';
    $userInit  = $authUser ? strtoupper(mb_substr(trim($authUser->name ?? ''), 0, 2)) : 'A';
    $homeUrl   = $guard === 'super_admin' ? url('/super-admin') : url('/dashboard');
    $logoutUrl = $guard === 'super_admin' ? route('super-admin.logout') : route('logout');
    $isRtl     = app()->getLocale() === 'ar';
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{ $isRtl ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title', 'Dashboard') — {{ $brandName }}</title>

    {{-- FontAwesome 6.4 (same build the client portal uses) --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    {{-- Bootstrap 4 + AdminLTE base (adminlte.min.css ships the full BS4 build) --}}
    <link rel="stylesheet" href="{{ asset('vendor/adminlte/dist/css/adminlte.min.css') }}">

    {{-- Global plugins (same CDNs the old layout loaded) --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">

    {{-- ISP client-portal design system skin (loaded last — wins the cascade) --}}
    <link rel="stylesheet" href="{{ asset('css/isp-admin.css') }}">

    {{-- AdminLTE "plugins.*" section contract: views may request
         Datatables via @section('plugins.Datatables', true) --}}
    @hasSection('plugins.Datatables')
        <link rel="stylesheet" href="{{ asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
    @endif

    @yield('css')
    @stack('css')
</head>
<body class="isp-shell {{ $isRtl ? 'isp-rtl' : '' }}">

{{-- ════════════════ TOPBAR ════════════════ --}}
<div class="isp-topbar">
    <div class="topbar-left">
        <button class="hamburger" id="ispSidebarToggle" type="button" aria-label="Toggle menu">
            <i class="fas fa-bars"></i>
        </button>
        <a href="{{ $homeUrl }}" class="topbar-brand">
            <div class="logo-box">{{ $initial }}</div>
            <span>{{ $brandName }}</span>
        </a>
    </div>

    <div class="topbar-right">
        @if($guard === 'web' && $authUser)
            {{-- Language switcher + notification bell (web-guard staff) --}}
            @include('partials.language-switcher')
            @include('partials.notification-bell')
        @endif

        @yield('content_top_nav_right')

        {{-- User pill (client-portal style) --}}
        @if($authUser)
        <div class="user-pill" id="ispUserPill" title="{{ $authUser->name }}">
            <div class="user-avatar">{{ $userInit }}</div>
            <span>{{ $authUser->name }}</span>
            <i class="fas fa-chevron-down chev"></i>

            <div class="user-dropdown" id="ispUserDropdown">
                <div class="dropdown-header">
                    <div class="dropdown-avatar">{{ $userInit }}</div>
                    <div>
                        <div class="dropdown-name">{{ $authUser->name }}</div>
                        <div class="dropdown-sub">{{ $authUser->email }}</div>
                    </div>
                </div>
                <div class="dropdown-divider"></div>
                <form method="POST" action="{{ $logoutUrl }}">
                    @csrf
                    <button type="submit" class="dropdown-item danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </button>
                </form>
            </div>
        </div>
        @endif
    </div>
</div>

{{-- ════════════════ SIDEBAR ════════════════ --}}
<div class="isp-sidebar" id="ispSidebar">
    <nav class="sidebar-nav">
        @include('partials.isp-menu-items', ['items' => config('adminlte.menu')])
        <div class="nav-divider"></div>
    </nav>
</div>
<div class="sidebar-backdrop" id="ispBackdrop"></div>

{{-- ════════════════ CONTENT ════════════════ --}}
<div class="isp-main-wrapper">
    <div class="isp-page-content">

        {{-- Flash toasts (legacy: some views post redirects) --}}
        @if(session('success') || session('error') || session('warning'))
            @php
                $type    = session('success') ? 'success' : (session('error') ? 'error' : 'warning');
                $message = session('success') ?? session('error') ?? session('warning');
                $color   = $type === 'success' ? '#00c897' : ($type === 'error' ? '#e74c3c' : '#f39c12');
                $icon    = $type === 'success' ? 'check-circle' : ($type === 'error' ? 'times-circle' : 'exclamation-triangle');
                $title   = $type === 'success' ? 'Success' : ($type === 'error' ? 'Error' : 'Warning');
            @endphp
            <div class="isp-flash-pos">
                <div class="toast show" role="alert"
                     style="border:none; border-radius:10px; box-shadow:0 8px 30px rgba(0,0,0,.15); overflow:hidden;">
                    <div class="toast-header" style="background:{{ $color }}; color:#fff; border:none;">
                        <i class="fas fa-{{ $icon }} mr-2"></i>
                        <strong class="mr-auto">{{ $title }}</strong>
                        <button type="button" class="ml-2 close" data-dismiss="toast" style="color:#fff; opacity:1;">&times;</button>
                    </div>
                    <div class="toast-body" style="background:#fff; font-size:13px; padding:12px 16px;">
                        {{ $message }}
                    </div>
                </div>
            </div>
        @endif

        @yield('content_header')
        @yield('content')
    </div>

    {{-- ════════════════ FOOTER ════════════════ --}}
    <div class="isp-footer">
        {{ date('Y') }} &copy; {{ $brandName }} — Admin Panel
    </div>
</div>

{{-- ════════════════ SCRIPTS ════════════════ --}}
<script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('vendor/adminlte/dist/js/adminlte.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    {{-- Datatables — only when the page requested it via plugins section --}}
    @hasSection('plugins.Datatables')
        <script src="{{ asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    @endif

<script src="{{ asset('js/isp-admin.js') }}"></script>

@yield('js')
@stack('js')
</body>
</html>
