{{-- resources/views/layouts/isp-auth.blade.php
     Shared standalone auth shell — replicates the Client Self-Service
     Portal login look (navy gradient bg · white 16px card · teal accents).
     Sections: title · subtitle · auth_content --}}
@php
    // Tenant DBs carry the settings table; the central (super-admin)
    // DB does not — fall back gracefully.
    try {
        $brandName = \App\Models\Setting::get('company_name', 'ISP Management');
    } catch (\Throwable $e) {
        $brandName = 'ISP Management';
    }
    $initial   = strtoupper(mb_substr(trim($brandName), 0, 1)) ?: 'I';
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Login') — {{ $brandName }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #1a1f36 0%, #2d3561 100%);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
            padding: 2rem 0;
        }
        .login-wrapper { width: 100%; max-width: 400px; padding: 1rem; }
        .login-card { background: #fff; border-radius: 16px; padding: 2.5rem 2rem; box-shadow: 0 20px 60px rgba(0,0,0,.3); }

        .brand { text-align: center; margin-bottom: 2rem; }
        .brand-logo {
            width: 60px; height: 60px; background: #00c897;
            border-radius: 14px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 12px; font-size: 26px; font-weight: 800; color: #fff;
        }
        .brand h1 { font-size: 20px; font-weight: 700; color: #1a1f36; }
        .brand p  { font-size: 13px; color: #888; margin-top: 4px; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 12px; font-weight: 600; color: #555; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .4px; }
        .input-wrap { position: relative; }
        .input-wrap i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #bbb; font-size: 14px; }
        .form-control {
            width: 100%; padding: 10px 12px 10px 38px;
            border: 1.5px solid #e0e4ef; border-radius: 8px;
            font-size: 13px; color: #333; outline: none; transition: border-color .2s;
        }
        .form-control:focus { border-color: #00c897; }
        .form-control.is-invalid { border-color: #e74c3c; }
        .invalid-feedback { font-size: 11px; color: #e74c3c; margin-top: 4px; }

        .btn-auth {
            width: 100%; padding: 12px; background: #00c897; color: #fff; border: none;
            border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; transition: background .2s;
        }
        .btn-auth:hover { background: #00b386; }
        .btn-auth.btn-secondary { background: #fff; color: #555; border: 1.5px solid #e0e4ef; }
        .btn-auth.btn-secondary:hover { background: #f5f6fa; }

        .alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 1rem; display: flex; gap: 8px; align-items: flex-start; }
        .alert-danger  { background: #fff0f0; color: #c0392b; border: 1px solid #ffd0d0; }
        .alert-success { background: #f0fff8; color: #1a7a50; border: 1px solid #b0e8d0; }
        .alert-info    { background: #f0f6ff; color: #2c5fa8; border: 1px solid #cfe0ff; }

        .hint-box {
            margin-top: 1.5rem; background: #f0faf7;
            border: 1px solid #b0e8d0; border-radius: 8px;
            padding: 12px 14px; font-size: 12px; color: #1a7a50; line-height: 1.6;
        }
        .hint-box strong { display: block; margin-bottom: 4px; }

        .foot-link { text-align: center; font-size: 13px; color: #888; margin-top: 1.25rem; }
        .foot-link a { color: #0e9e77; text-decoration: none; }
        .foot-link a:hover { text-decoration: underline; }

        .muted-note { font-size: 13px; color: #888; line-height: 1.6; margin-bottom: 1.25rem; }

        /* — mobile: full-width, compact card — */
        @media (max-width: 480px) {
            body { padding: 1rem 0; align-items: flex-start; }
            .login-wrapper { padding: 0 12px; }
            .login-card { padding: 1.75rem 1.25rem; border-radius: 14px; }
            .brand h1 { font-size: 18px; }
        }
    </style>
</head>
<body>
<div class="login-wrapper">
    <div class="login-card">
        <div class="brand">
            <div class="brand-logo">{{ $initial }}</div>
            <h1>{{ $brandName }}</h1>
            <p>@yield('subtitle', 'Admin &amp; Staff Portal')</p>
        </div>

        @yield('auth_content')
    </div>
</div>
</body>
</html>
