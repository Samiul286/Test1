{{-- resources/views/layouts/app.blade.php
     ISP Admin / Staff wrapper around the master `layouts.isp`
     chrome (client-portal UI/UX). Kept section contract of the
     previous version so child views are untouched:
       page_title · page_actions · page_content · extra_css · extra_js --}}
@extends('layouts.isp', ['guard' => 'web'])

@section('title')@yield('page_title', 'Dashboard')@endsection

@section('content_header')
    <div class="isp-page-head">
        <h1>@yield('page_title', 'Dashboard')</h1>
        <div class="page-actions">@yield('page_actions')</div>
    </div>
@stop

@section('content')
    {{-- Quick Add Category Modal (shared for Income & Expense) --}}
    @include('accounting._quick_add_category_modal')

    @yield('page_content')
@stop

@section('css')
    @yield('extra_css')
    @stack('css')
@stop

@section('js')
    @yield('extra_js')
    @stack('js')
@stop
