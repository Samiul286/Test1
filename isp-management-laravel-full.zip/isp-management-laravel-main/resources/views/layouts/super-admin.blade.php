{{-- resources/views/layouts/super-admin.blade.php
     Super Admin wrapper around the master `layouts.isp` chrome
     (client-portal UI/UX). Uses the dedicated 'super_admin' guard —
     the master layout reads the user from the correct guard and
     swaps the brand home + logout routes automatically. --}}
@extends('layouts.isp', ['guard' => 'super_admin'])

@section('title')@yield('page_title', 'Super Admin')@endsection

@section('content_header')
    <div class="isp-page-head">
        <h1>@yield('page_title', 'Super Admin Dashboard')</h1>
        <div class="page-actions">@yield('page_actions')</div>
    </div>
@stop

@section('content')
    @yield('page_content')
@stop

@section('css')
    @yield('extra_css')
    @stack('css')
@stop

@section('js')
    @yield('extra_js')
    @stack('js')
@stop
