{{-- resources/views/auth/forgot-password.blade.php --}}
@extends('layouts.isp-auth')

@section('title', 'Forgot Password')
@section('subtitle', 'Reset your password')

@section('auth_content')
    <p class="muted-note">
        Forgot your password? No problem. Just let us know your email address
        and we will email you a password reset link that will allow you to
        choose a new one.
    </p>

    @if(session('status'))
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ session('status') }}</div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle" style="margin-top:1px;"></i>
            <span>{{ $errors->first() }}</span>
        </div>
    @endif

    <form method="POST" action="{{ route('password.email') }}">
        @csrf

        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="you@example.com" value="{{ old('email') }}"
                    autocomplete="username" required autofocus>
            </div>
        </div>

        <button type="submit" class="btn-auth">
            <i class="fas fa-paper-plane" style="margin-right:6px;"></i> Email Password Reset Link
        </button>
    </form>

    <div class="foot-link">
        <a href="{{ route('login') }}"><i class="fas fa-arrow-left"></i> Back to login</a>
    </div>
@endsection
