{{-- resources/views/auth/verify-email.blade.php --}}
@extends('layouts.isp-auth')

@section('title', 'Verify Email')
@section('subtitle', 'Verify your email address')

@section('auth_content')
    <p class="muted-note">
        Thanks for signing up! Before getting started, could you verify your
        email address by clicking on the link we just emailed to you? If you
        didn't receive the email, we will gladly send you another.
    </p>

    @if(session('status') == 'verification-link-sent')
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <span>A new verification link has been sent to the email address you provided during registration.</span>
        </div>
    @endif

    <form method="POST" action="{{ route('verification.send') }}">
        @csrf
        <button type="submit" class="btn-auth">
            <i class="fas fa-redo" style="margin-right:6px;"></i> Resend Verification Email
        </button>
    </form>

    <form method="POST" action="{{ route('logout') }}" style="margin-top:10px;">
        @csrf
        <button type="submit" class="btn-auth btn-secondary">
            <i class="fas fa-sign-out-alt" style="margin-right:6px;"></i> Log Out
        </button>
    </form>
@endsection
