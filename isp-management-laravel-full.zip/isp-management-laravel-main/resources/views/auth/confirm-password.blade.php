{{-- resources/views/auth/confirm-password.blade.php --}}
@extends('layouts.isp-auth')

@section('title', 'Confirm Password')
@section('subtitle', 'Secure area — confirm your password')

@section('auth_content')
    <p class="muted-note">
        This is a secure area of the application. Please confirm your
        password before continuing.
    </p>

    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle" style="margin-top:1px;"></i>
            <span>{{ $errors->first() }}</span>
        </div>
    @endif

    <form method="POST" action="{{ route('password.confirm') }}">
        @csrf

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="Your current password"
                    autocomplete="current-password" required autofocus>
            </div>
        </div>

        <button type="submit" class="btn-auth">
            <i class="fas fa-shield-alt" style="margin-right:6px;"></i> Confirm
        </button>
    </form>
@endsection
