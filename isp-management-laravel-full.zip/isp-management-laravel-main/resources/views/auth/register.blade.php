{{-- resources/views/auth/register.blade.php
     Staff registration — same client-portal auth design. --}}
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — {{ \App\Models\Setting::get('company_name', 'ISP Management') }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #1a1f36 0%, #2d3561 100%);
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
            padding: 2rem 0;
        }
        .login-wrapper { width: 100%; max-width: 400px; padding: 1rem; }
        .login-card { background: #fff; border-radius: 16px; padding: 2.5rem 2rem; box-shadow: 0 20px 60px rgba(0,0,0,.3); }
        .brand { text-align: center; margin-bottom: 2rem; }
        .brand-logo {
            width: 60px; height: 60px; background: #00c897; border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 12px; font-size: 26px; font-weight: 800; color: #fff;
        }
        .brand h1 { font-size: 20px; font-weight: 700; color: #1a1f36; }
        .brand p  { font-size: 13px; color: #888; margin-top: 4px; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 12px; font-weight: 600; color: #555; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .4px; }
        .input-wrap { position: relative; }
        .input-wrap i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #bbb; font-size: 14px; }
        .form-control {
            width: 100%; padding: 10px 12px 10px 38px;
            border: 1.5px solid #e0e4ef; border-radius: 8px;
            font-size: 13px; color: #333; outline: none; transition: border-color .2s;
        }
        .form-control:focus { border-color: #00c897; }
        .form-control.is-invalid { border-color: #e74c3c; }
        .invalid-feedback { font-size: 11px; color: #e74c3c; margin-top: 4px; }

        .btn-login {
            width: 100%; padding: 12px; background: #00c897; color: #fff; border: none;
            border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; transition: background .2s;
        }
        .btn-login:hover { background: #00b386; }

        .alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 1rem; display: flex; gap: 8px; }
        .alert-danger  { background: #fff0f0; color: #c0392b; border: 1px solid #ffd0d0; }

        .foot-link { text-align: center; font-size: 13px; color: #888; margin-top: 1.25rem; }
        .foot-link a { color: #0e9e77; text-decoration: none; }
        .foot-link a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="login-wrapper">
    <div class="login-card">
        <div class="brand">
            <div class="brand-logo">{{ strtoupper(substr(\App\Models\Setting::get('company_name', 'I'), 0, 1)) }}</div>
            <h1>{{ \App\Models\Setting::get('company_name', 'ISP Management') }}</h1>
            <p>Create a staff account</p>
        </div>

        @if($errors->any())
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle" style="margin-top:1px;"></i>
                <span>{{ $errors->first() }}</span>
            </div>
        @endif

        <form method="POST" action="{{ url('/register') }}">
            @csrf

            <div class="form-group">
                <label>Full Name</label>
                <div class="input-wrap">
                    <i class="fas fa-user"></i>
                    <input type="text" name="name"
                        class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}"
                        placeholder="Your full name" value="{{ old('name') }}"
                        autocomplete="name" required autofocus>
                </div>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email"
                        class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                        placeholder="you@example.com" value="{{ old('email') }}"
                        autocomplete="username" required>
                </div>
            </div>

            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password"
                        class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                        placeholder="Create a password" autocomplete="new-password" required>
                </div>
            </div>

            <div class="form-group">
                <label>Confirm Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password_confirmation"
                        class="form-control {{ $errors->has('password_confirmation') ? 'is-invalid' : '' }}"
                        placeholder="Repeat the password" autocomplete="new-password" required>
                </div>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-user-plus" style="margin-right:6px;"></i> Register
            </button>
        </form>

        <div class="foot-link">
            Already have an account? <a href="{{ route('login') }}">Login here</a>
        </div>
    </div>
</div>
</body>
</html>
