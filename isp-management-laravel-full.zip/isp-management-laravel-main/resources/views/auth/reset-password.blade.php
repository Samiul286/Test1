{{-- resources/views/auth/reset-password.blade.php --}}
@extends('layouts.isp-auth')

@section('title', 'Reset Password')
@section('subtitle', 'Choose a new password')

@section('auth_content')
    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle" style="margin-top:1px;"></i>
            <span>{{ $errors->first() }}</span>
        </div>
    @endif

    <form method="POST" action="{{ route('password.store') }}">
        @csrf

        {{-- Password Reset Token --}}
        <input type="hidden" name="token" value="{{ $request->route('token') }}">

        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="you@example.com"
                    value="{{ old('email', $request->email) }}"
                    autocomplete="username" required autofocus>
            </div>
        </div>

        <div class="form-group">
            <label>New Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="New password" autocomplete="new-password" required>
            </div>
        </div>

        <div class="form-group">
            <label>Confirm Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password_confirmation"
                    class="form-control {{ $errors->has('password_confirmation') ? 'is-invalid' : '' }}"
                    placeholder="Repeat the new password" autocomplete="new-password" required>
            </div>
        </div>

        <button type="submit" class="btn-auth">
            <i class="fas fa-key" style="margin-right:6px;"></i> Reset Password
        </button>
    </form>

    <div class="foot-link">
        <a href="{{ route('login') }}"><i class="fas fa-arrow-left"></i> Back to login</a>
    </div>
@endsection
