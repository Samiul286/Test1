@extends('layouts.isp')
@section('title', 'Purchase List')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="mb-0 font-weight-bold text-dark">
                <i class="fas fa-file-invoice-dollar mr-2 text-primary"></i>Purchase Bills
            </h4>
            <small class="text-muted">Upstream bandwidth purchase invoices</small>
        </div>
        <a href="{{ route('bandwidth-buy.purchase.create') }}" class="btn btn-primary btn-sm px-3">
            <i class="fas fa-plus mr-1"></i> New Purchase
        </a>
    </div>
@endsection

@section('content')

@if(session('success'))
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <i class="fas fa-check-circle mr-1"></i> {{ session('success') }}
    </div>
@endif

{{-- ── Summary Cards (Customer-style) ─────────────────────────────────────── --}}
<style>
.cust-stat-card {
    border-radius: 4px;
    color: #fff;
    padding: 14px 16px;
    margin-bottom: 16px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    overflow: hidden;
}
.cust-stat-card .sc-left .sc-label {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .5px;
    color: rgba(255,255,255,.85);
    margin-bottom: 4px;
}
.cust-stat-card .sc-left .sc-value {
    font-size: 32px;
    font-weight: 700;
    line-height: 1;
    color: #fff;
}
.cust-stat-card .sc-icon {
    font-size: 52px;
    color: rgba(255,255,255,.18);
}
</style>
<div class="row mb-3">
    <div class="col-md-3 col-sm-6">
        <div class="cust-stat-card" style="background:#17a2b8;">
            <div class="sc-left">
                <div class="sc-label"><i class="fas fa-file-invoice mr-1"></i> Total Bills</div>
                <div class="sc-value">{{ $purchases->total() }}</div>
            </div>
            <div class="sc-icon"><i class="fas fa-file-invoice"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="cust-stat-card" style="background:#00a65a;">
            <div class="sc-left">
                <div class="sc-label"><i class="fas fa-check-circle mr-1"></i> Total Paid</div>
                <div class="sc-value">৳ {{ number_format($purchases->sum('paid')) }}</div>
            </div>
            <div class="sc-icon"><i class="fas fa-check-circle"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="cust-stat-card" style="background:#dd4b39;">
            <div class="sc-left">
                <div class="sc-label"><i class="fas fa-exclamation-circle mr-1"></i> Total Due</div>
                <div class="sc-value">৳ {{ number_format($purchases->sum('due')) }}</div>
            </div>
            <div class="sc-icon"><i class="fas fa-exclamation-circle"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="cust-stat-card" style="background:#f39c12;">
            <div class="sc-left">
                <div class="sc-label"><i class="fas fa-money-bill-wave mr-1"></i> Grand Total</div>
                <div class="sc-value">৳ {{ number_format($purchases->sum('sub_total')) }}</div>
            </div>
            <div class="sc-icon"><i class="fas fa-money-bill-wave"></i></div>
        </div>
    </div>
</div>

{{-- ── Table Card ──────────────────────────────────────────────────────────── --}}
<div class="card shadow-sm">
    <div class="card-header py-2 d-flex justify-content-between align-items-center"
         style="background:linear-gradient(135deg,#1a237e 0%,#283593 100%);">
        <h6 class="m-0 text-white font-weight-bold">
            <i class="fas fa-list mr-1"></i> Purchase List
        </h6>
        <input type="text" id="searchInput" class="form-control form-control-sm"
               placeholder="Search invoice / provider..." style="width:220px; border-radius:20px;">
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" id="purchaseTable">
                <thead>
                    <tr style="background:#f8f9fa; border-bottom:2px solid #dee2e6;">
                        <th class="text-center" style="width:50px;">#</th>
                        <th>Invoice No</th>
                        <th>Provider</th>
                        <th class="text-center">Document</th>
                        <th>Billing Date</th>
                        <th class="text-right">Sub Total (৳)</th>
                        <th class="text-right">Paid (৳)</th>
                        <th class="text-right">Due (৳)</th>
                        <th class="text-center">Status</th>
                        <th class="text-center" style="width:150px;">Actions</th>
                    </tr>
                </thead>
                <tbody id="purchaseTableBody">
                    @forelse($purchases as $i => $p)
                    <tr>
                        <td class="text-center text-muted small">{{ $purchases->firstItem() + $i }}</td>
                        <td>
                            <span class="font-weight-bold text-primary">{{ $p->invoice_no }}</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="mr-2"
                                     style="width:32px;height:32px;border-radius:50%;
                                            background:{{ ['#1976D2','#388E3C','#F57C00','#7B1FA2','#C62828','#00838F'][($p->provider_id - 1) % 6] }};
                                            display:flex;align-items:center;justify-content:center;
                                            color:#fff;font-weight:700;font-size:13px;flex-shrink:0;">
                                    {{ strtoupper(substr($p->provider->company_name ?? 'P', 0, 1)) }}
                                </div>
                                <span class="font-weight-bold">{{ $p->provider->company_name ?? '—' }}</span>
                            </div>
                        </td>
                        <td class="text-center">
                            @if($p->document)
                                <img src="{{ asset('storage/'.$p->document) }}"
                                     style="height:40px;width:60px;object-fit:contain;border-radius:4px;
                                            border:1px solid #eee;background:#fff;padding:2px;">
                            @else
                                <span class="badge badge-light border text-muted small">No Image</span>
                            @endif
                        </td>
                        <td>
                            <i class="fas fa-calendar-alt text-muted mr-1"></i>
                            {{ $p->billing_date->format('d M Y') }}
                        </td>
                        <td class="text-right font-weight-bold">
                            {{ number_format($p->sub_total, 2) }}
                        </td>
                        <td class="text-right text-success font-weight-bold">
                            {{ number_format($p->paid, 2) }}
                        </td>
                        <td class="text-right font-weight-bold {{ $p->due > 0 ? 'text-danger' : 'text-muted' }}">
                            {{ number_format($p->due, 2) }}
                            @if($p->due > 0)
                                <i class="fas fa-exclamation-circle ml-1"></i>
                            @endif
                        </td>
                        <td class="text-center">
                            {{-- Status Badge --}}
                            {!! $p->statusBadge !!}
                        </td>
                        <td class="text-center">
                            {{-- View Lines Button --}}
                            <button class="btn btn-sm btn-info btn-view-lines px-2"
                                    data-id="{{ $p->id }}"
                                    data-invoice="{{ $p->invoice_no }}"
                                    data-provider="{{ $p->provider->company_name ?? '' }}"
                                    data-date="{{ $p->billing_date->format('d M Y') }}"
                                    data-total="{{ number_format($p->sub_total, 2) }}"
                                    data-paid="{{ number_format($p->paid, 2) }}"
                                    data-due="{{ number_format($p->due, 2) }}"
                                    data-bank="{{ $p->bank_account ?? '' }}"
                                    title="View Details">
                                <i class="fas fa-eye"></i>
                            </button>
                            {{-- Pay Button — Due/Partial হলে দেখাবে --}}
                            @if($p->isDue() || $p->isPartial())
                            <button class="btn btn-sm btn-success btn-pay px-2"
                                    data-id="{{ $p->id }}"
                                    data-invoice="{{ $p->invoice_no }}"
                                    data-due="{{ $p->due }}"
                                    title="Pay">
                                <i class="fas fa-money-bill-wave"></i>
                            </button>
                            @endif
                            {{-- Edit Button — শুধু Due হলে --}}
                            @if($p->isEditable())
                            <a href="{{ route('bandwidth-buy.purchase.edit', $p) }}"
                               class="btn btn-sm btn-warning px-2" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="9" class="text-center py-5 text-muted">
                            <i class="fas fa-file-invoice fa-3x mb-3 d-block" style="opacity:.2;"></i>
                            No purchase bills found. Click <strong>+ New Purchase</strong> to add one.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @if($purchases->hasPages())
    <div class="card-footer bg-light py-2">
        {{ $purchases->links() }}
    </div>
    @endif
</div>


{{-- ══════════════════════════════════════════════════════════════════════════ --}}
{{-- VOID PURCHASE MODAL                                                        --}}
{{-- ══════════════════════════════════════════════════════════════════════════ --}}
<div class="modal fade" id="voidModal" tabindex="-1" data-backdrop="static">
    <div class="modal-dialog modal-md">
        <div class="modal-content border-0 shadow-lg" style="border-radius:10px; overflow:hidden;">
            <div class="modal-header border-0 py-3"
                 style="background:linear-gradient(135deg,#b71c1c,#c62828);">
                <h5 class="modal-title text-white font-weight-bold">
                    <i class="fas fa-ban mr-2"></i>Void Purchase
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body px-4 py-3">

                {{-- Warning box --}}
                <div class="alert border-0 mb-3 py-2 px-3"
                     style="background:#fff3e0; border-left:4px solid #f57c00 !important; border-radius:6px;">
                    <i class="fas fa-exclamation-triangle text-warning mr-2"></i>
                    <strong>Invoice: <span id="voidInvoiceLabel" class="text-danger"></span></strong>
                    <div class="mt-1 text-muted" style="font-size:13px;">
                        এই purchase void করলে Accounting এ এর সব linked expense গুলোও
                        <strong>automatically void</strong> হয়ে যাবে।
                        এই action টা <strong>undo করা যাবে না।</strong>
                    </div>
                </div>

                {{-- Reason --}}
                <div class="form-group mb-0">
                    <label class="font-weight-bold text-dark" style="font-size:13px;">
                        Void Reason <span class="text-danger">*</span>
                    </label>
                    <textarea id="voidReason" class="form-control" rows="3"
                              placeholder="e.g. Duplicate entry, wrong invoice, cancelled order..."
                              style="border-radius:8px; font-size:13px; resize:none;"></textarea>
                    <small class="text-danger d-none" id="voidReasonError">
                        <i class="fas fa-exclamation-circle mr-1"></i>কারণ লিখতে হবে।
                    </small>
                </div>

            </div>
            <div class="modal-footer border-0 bg-light px-4 py-3">
                <button type="button" class="btn btn-light border px-4" data-dismiss="modal">
                    <i class="fas fa-times mr-1"></i>Cancel
                </button>
                <button type="button" class="btn btn-danger px-4" id="btnConfirmVoid">
                    <i class="fas fa-ban mr-1"></i>Confirm Void
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Hidden void forms (one per purchase) --}}
@foreach($purchases as $p)
<form id="voidForm{{ $p->id }}"
      action="{{ route('bandwidth-buy.purchase.void', $p) }}"
      method="POST" style="display:none;">
    @csrf
    <input type="hidden" name="reason" id="voidReasonInput{{ $p->id }}">
</form>
@endforeach
<div class="modal fade" id="linesModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content border-0 shadow-lg">

            {{-- Header --}}
            <div class="modal-header text-white border-0 py-3"
                 style="background:linear-gradient(135deg,#1a237e 0%,#283593 100%); border-radius:8px 8px 0 0;">
                <div>
                    <h5 class="modal-title font-weight-bold mb-0">
                        <i class="fas fa-list-alt mr-2"></i>
                        Invoice: <span id="mInvoice" class="text-warning"></span>
                    </h5>
                    <small class="text-white-50">
                        <i class="fas fa-building mr-1"></i><span id="mProvider"></span>
                        &nbsp;|&nbsp;
                        <i class="fas fa-calendar mr-1"></i><span id="mDate"></span>
                    </small>
                </div>
                <button type="button" class="close text-white" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body p-0">

                {{-- Summary bar --}}
                <div class="d-flex border-bottom px-4 py-3" style="background:#f8f9fa; gap:24px; flex-wrap:wrap;">
                    <div class="text-center">
                        <div class="text-muted small">Sub Total</div>
                        <div class="font-weight-bold text-dark h6 mb-0" id="mTotal"></div>
                    </div>
                    <div class="text-center">
                        <div class="text-muted small">Paid</div>
                        <div class="font-weight-bold text-success h6 mb-0" id="mPaid"></div>
                    </div>
                    <div class="text-center">
                        <div class="text-muted small">Due</div>
                        <div class="font-weight-bold h6 mb-0" id="mDue"></div>
                    </div>
                    <div class="text-center" id="mBankWrap" style="display:none!important;">
                        <div class="text-muted small">Bank Account</div>
                        <div class="font-weight-bold text-dark small mb-0" id="mBank"></div>
                    </div>
                </div>

                {{-- Lines table --}}
                <div class="table-responsive px-0">
                    <table class="table table-hover mb-0" id="linesTable">
                        <thead>
                            <tr style="background:#f1f3f8; border-bottom:2px solid #dee2e6;">
                                <th class="text-center pl-4" style="width:50px;">#</th>
                                <th>Service</th>
                                <th>From Date</th>
                                <th>To Date</th>
                                <th class="text-right">Qty (MB)</th>
                                <th class="text-right">Rate (৳)</th>
                                <th class="text-center">VAT (%)</th>
                                <th class="text-right pr-4">Line Total (৳)</th>
                            </tr>
                        </thead>
                        <tbody id="linesTableBody">
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    <i class="fas fa-spinner fa-spin mr-1"></i> Loading...
                                </td>
                            </tr>
                        </tbody>
                        <tfoot id="linesTableFoot" style="display:none;">
                            <tr style="background:#e8eaf6;">
                                <td colspan="7" class="text-right font-weight-bold pr-3">Grand Total</td>
                                <td class="text-right font-weight-bold pr-4" id="mGrandTotal"></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            {{-- Footer --}}
            <div class="modal-footer border-0 bg-light px-4" style="border-radius:0 0 8px 8px;">
                <a href="#" id="mEditBtn" class="btn btn-warning px-4">
                    <i class="fas fa-edit mr-1"></i> Edit Purchase
                </a>
                <button type="button" class="btn btn-light border px-4" data-dismiss="modal">
                    <i class="fas fa-times mr-1"></i> Close
                </button>
            </div>

        </div>
    </div>
</div>

@endsection

{{-- ══════════════════════════════════════════════════════════════════════════ --}}
{{-- PAY MODAL                                                                   --}}
{{-- ══════════════════════════════════════════════════════════════════════════ --}}
<div class="modal fade" id="payModal" tabindex="-1" data-backdrop="static">
    <div class="modal-dialog modal-md">
        <div class="modal-content border-0 shadow-lg" style="border-radius:10px; overflow:hidden;">
            <div class="modal-header border-0 py-3"
                 style="background:linear-gradient(135deg,#1b5e20,#2e7d32);">
                <h5 class="modal-title text-white font-weight-bold">
                    <i class="fas fa-money-bill-wave mr-2"></i>
                    Pay — Invoice: <span id="payInvoiceLabel" class="text-warning"></span>
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body px-4 py-3">
                <div class="alert border-0 mb-3 py-2 px-3"
                     style="background:#e8f5e9; border-left:4px solid #2e7d32 !important; border-radius:6px;">
                    <i class="fas fa-info-circle text-success mr-1"></i>
                    Balance Due: <strong class="text-danger" id="payDueLabel"></strong>
                    <br><small class="text-muted">Payment save হলে Accounting → Expense এ automatically record হবে।</small>
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" style="font-size:13px;">Amount <span class="text-danger">*</span></label>
                    <input type="number" id="payAmount" class="form-control" min="0.01" step="0.01" placeholder="0.00">
                    <small class="text-danger d-none" id="payAmountError">Amount is required and cannot exceed due.</small>
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" style="font-size:13px;">Payment Date <span class="text-danger">*</span></label>
                    <input type="date" id="payDate" class="form-control" value="{{ date('Y-m-d') }}">
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" style="font-size:13px;">Payment Method <span class="text-danger">*</span></label>
                    <select id="payMethod" class="form-control">
                        <option value="bank">Bank</option>
                        <option value="cash">Cash</option>
                        <option value="bkash">bKash</option>
                        <option value="nagad">Nagad</option>
                        <option value="rocket">Rocket</option>
                        <option value="cheque">Cheque</option>
                        <option value="card">Card</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" style="font-size:13px;">Transaction No</label>
                    <input type="text" id="payTxNo" class="form-control" placeholder="Optional">
                </div>
                <div class="form-group mb-0">
                    <label class="font-weight-bold" style="font-size:13px;">Remarks</label>
                    <input type="text" id="payRemarks" class="form-control" placeholder="Optional">
                </div>
            </div>
            <div class="modal-footer border-0 bg-light px-4 py-3">
                <button type="button" class="btn btn-light border px-4" data-dismiss="modal">
                    <i class="fas fa-times mr-1"></i>Cancel
                </button>
                <button type="button" class="btn btn-success px-4" id="btnConfirmPay">
                    <i class="fas fa-check mr-1"></i>Confirm Payment
                </button>
                <button type="button" class="btn btn-outline-info px-3" id="btnViewHistory">
                    <i class="fas fa-history mr-1"></i>History
                </button>
            </div>
        </div>
    </div>
</div>

{{-- ══════════════════════════════════════════════════════════════════════════ --}}
{{-- PAYMENT HISTORY MODAL                                                       --}}
{{-- ══════════════════════════════════════════════════════════════════════════ --}}
<div class="modal fade" id="payHistoryModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow-lg" style="border-radius:10px; overflow:hidden;">
            <div class="modal-header border-0 py-3"
                 style="background:linear-gradient(135deg,#1a237e,#283593);">
                <h5 class="modal-title text-white font-weight-bold">
                    <i class="fas fa-history mr-2"></i>Payment History — <span id="histInvoiceLabel" class="text-warning"></span>
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead style="background:#f8f9fa;">
                            <tr>
                                <th>#</th>
                                <th>Date</th>
                                <th>Amount (৳)</th>
                                <th>Method</th>
                                <th>Tx No</th>
                                <th>Remarks</th>
                                <th>Created By</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="histTableBody">
                            <tr><td colspan="7" class="text-center py-4 text-muted">Loading...</td></tr>
                        </tbody>
                        <tfoot id="histTableFoot" style="display:none; background:#e8eaf6;">
                            <tr>
                                <td colspan="2" class="text-right font-weight-bold pr-3">Total Paid</td>
                                <td class="font-weight-bold text-success" id="histTotal"></td>
                                <td colspan="4"></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="modal-footer border-0 bg-light px-4">
                <button type="button" class="btn btn-light border px-4" data-dismiss="modal">
                    <i class="fas fa-times mr-1"></i>Close
                </button>
            </div>
        </div>
    </div>
</div>

@section('css')
<style>
    #purchaseTable tbody tr:hover { background:#f0f4ff !important; }
    #purchaseTable thead th {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .5px;
        color: #555;
        padding: 10px 12px;
    }
    #purchaseTable tbody td { padding: 10px 12px; vertical-align: middle; }

    #linesTable thead th {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .4px;
        color: #555;
        padding: 10px 12px;
    }
    #linesTable tbody td { padding: 10px 12px; vertical-align: middle; }
    #linesTable tbody tr:hover { background: #f0f4ff !important; }

    #searchInput:focus { box-shadow: 0 0 0 3px rgba(26,35,126,.15); border-color:#1a237e; }
    .modal-content { border-radius: 10px; overflow: hidden; }

    /* Toastr on top */
    #toast-container { z-index: 99999 !important; }
    .toast { z-index: 99999 !important; }

    /* service badge */
    .svc-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: .4px;
    }
</style>
@stop

@section('js')
@parent
<script>
const CSRF = '{{ csrf_token() }}';

// Per-purchase line data — PHP renders into JS
const PURCHASE_LINES = {
    @foreach($purchases as $p)
    {{ $p->id }}: [
        @foreach($p->lines as $line)
        {
            service:   @json($line->service->name ?? ''),
            from_date: @json(optional($line->from_date)->format('d M Y') ?? ''),
            to_date:   @json(optional($line->to_date)->format('d M Y') ?? ''),
            qty:       @json(number_format((float)$line->quantity_mb, 2)),
            rate:      @json(number_format((float)$line->rate, 2)),
            vat:       @json(number_format((float)$line->vat_percent, 2)),
            total:     @json(number_format((float)$line->line_total, 2)),
        },
        @endforeach
    ],
    @endforeach
};

const SVC_COLORS = [
    {bg:'#E3F2FD',txt:'#1565C0'},
    {bg:'#E8F5E9',txt:'#2E7D32'},
    {bg:'#FFF3E0',txt:'#E65100'},
    {bg:'#F3E5F5',txt:'#6A1B9A'},
    {bg:'#FCE4EC',txt:'#B71C1C'},
    {bg:'#E0F7FA',txt:'#006064'},
];
let svcColorMap = {};
let svcColorIdx = 0;
function svcColor(name) {
    if (!svcColorMap[name]) {
        svcColorMap[name] = SVC_COLORS[svcColorIdx % SVC_COLORS.length];
        svcColorIdx++;
    }
    return svcColorMap[name];
}

$(function () {

    toastr.options = {
        closeButton: true, progressBar: true,
        positionClass: 'toast-top-right',
        timeOut: 3500, preventDuplicates: true,
    };

    // ── Live search ───────────────────────────────────────────────────────────
    $('#searchInput').on('input', function () {
        const q = $(this).val().toLowerCase();
        $('#purchaseTableBody tr').each(function () {
            $(this).toggle($(this).text().toLowerCase().includes(q));
        });
    });

    // ── Void purchase ─────────────────────────────────────────────────────────
    let currentVoidId = null;

    $(document).on('click', '.btn-void', function () {
        currentVoidId = $(this).data('id');
        const invoice = $(this).data('invoice');
        $('#voidInvoiceLabel').text(invoice);
        $('#voidReason').val('');
        $('#voidReasonError').addClass('d-none');
        $('#voidModal').modal('show');
    });

    $('#btnConfirmVoid').on('click', function () {
        const reason = $('#voidReason').val().trim();
        if (!reason) {
            $('#voidReasonError').removeClass('d-none');
            $('#voidReason').focus();
            return;
        }

        $('#voidReasonError').addClass('d-none');
        $(`#voidReasonInput${currentVoidId}`).val(reason);

        $(this).prop('disabled', true)
               .html('<i class="fas fa-spinner fa-spin mr-1"></i>Processing...');

        $(`#voidForm${currentVoidId}`).submit();
    });
    // ── Pay button ────────────────────────────────────────────────
    let currentPayId = null;
    let currentPayDue = 0;

    $(document).on('click', '.btn-pay', function () {
        currentPayId  = $(this).data('id');
        currentPayDue = parseFloat($(this).data('due'));
        $('#payInvoiceLabel').text($(this).data('invoice'));
        $('#payDueLabel').text('৳ ' + currentPayDue.toLocaleString('en-US', {minimumFractionDigits:2}));
        $('#payAmount').val('').attr('max', currentPayDue);
        $('#payTxNo').val('');
        $('#payRemarks').val('');
        $('#payAmountError').addClass('d-none');
        $('#payDate').val('{{ date("Y-m-d") }}');
        $('#payModal').modal('show');
    });

    $('#btnConfirmPay').off('click').on('click', function () {
        const amount = parseFloat($('#payAmount').val()) || 0;
        if (amount <= 0 || amount > currentPayDue) {
            $('#payAmountError').removeClass('d-none');
            return;
        }
        $('#payAmountError').addClass('d-none');
        $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i>Processing...');

        $.ajax({
            url:    `/bandwidth-buy/purchase/${currentPayId}/pay`,
            method: 'POST',
            data: {
                _token:         CSRF,
                amount:         amount,
                payment_date:   $('#payDate').val(),
                payment_method: $('#payMethod').val(),
                transaction_no: $('#payTxNo').val(),
                remarks:        $('#payRemarks').val(),
            },
            success: function (res) {
                toastr.success(res.message);
                $('#payModal').modal('hide');
                setTimeout(() => location.reload(), 1500);
            },
            error: function (xhr) {
                toastr.error(xhr.responseJSON?.message || 'Payment failed.');
                $('#btnConfirmPay').prop('disabled', false).html('<i class="fas fa-check mr-1"></i>Confirm Payment');
            }
        });
    });

    // ── Payment History ───────────────────────────────────────────
    $('#btnViewHistory').on('click', function () {
        $('#histInvoiceLabel').text($('#payInvoiceLabel').text());
        $('#histTableBody').html('<tr><td colspan="7" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin mr-1"></i> Loading...</td></tr>');
        $('#histTableFoot').hide();
        $('#payHistoryModal').modal('show');

        $.get(`/bandwidth-buy/purchase/${currentPayId}/payment-history`, function (res) {
            if (!res.payments.length) {
                $('#histTableBody').html('<tr><td colspan="8" class="text-center py-4 text-muted">No payments yet.</td></tr>');
                return;
            }
            let html = '';
            res.payments.forEach(function (p, i) {
                html += `<tr id="hist-pay-row-${p.id}">
                    <td>${i+1}</td>
                    <td>${p.payment_date}</td>
                    <td class="font-weight-bold text-success">৳ ${p.amount}</td>
                    <td><span class="badge badge-light border">${p.payment_method}</span></td>
                    <td>${p.transaction_no}</td>
                    <td>${p.remarks}</td>
                    <td>${p.created_by}</td>
                    <td>
                        <button class="btn btn-xs btn-danger btn-void-payment"
                                data-id="${p.id}"
                                data-no="${p.payment_no}"
                                title="Void Payment">
                            <i class="fas fa-ban"></i>
                        </button>
                    </td>
                </tr>`;
            });
            $('#histTableBody').html(html);
            $('#histTotal').text('৳ ' + res.total);
            $('#histTableFoot').show();
        });
    });

    // ── Void individual payment ───────────────────────────────────
    $(document).on('click', '.btn-void-payment', function () {
        const payId = $(this).data('id');
        const payNo = $(this).data('no');

        Swal.fire({
            title: 'Void Payment?',
            html: `Payment <code>${payNo}</code> void হবে।<br>
                   <strong class="text-success">Accounting Expense ও void হবে।</strong>`,
            icon: 'warning',
            input: 'text',
            inputPlaceholder: 'Void reason (required)',
            inputAttributes: { autocomplete: 'off' },
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            confirmButtonText: 'Void',
            cancelButtonText: 'Cancel',
            reverseButtons: true,
            preConfirm: function (val) {
                if (!val || !val.trim()) Swal.showValidationMessage('Reason required.');
                return val;
            }
        }).then(function (r) {
            if (!r.isConfirmed) return;
            $.ajax({
                url:    `/bandwidth-buy/purchase/payment/${payId}/void`,
                method: 'POST',
                data:   { _token: CSRF, reason: r.value },
                success: function (res) {
                    toastr.success(res.message);
                    $(`#hist-pay-row-${payId}`).fadeOut();
                    setTimeout(() => location.reload(), 1500);
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON?.message || 'Void failed.');
                }
            });
        });
    });
    $(document).on('click', '.btn-view-lines', function () {
        const $btn    = $(this);
        const id      = $btn.data('id');
        const invoice = $btn.data('invoice');
        const due     = $btn.data('due');
        const bank    = $btn.data('bank');

        // Populate header
        $('#mInvoice').text(invoice);
        $('#mProvider').text($btn.data('provider'));
        $('#mDate').text($btn.data('date'));
        $('#mTotal').text('৳ ' + $btn.data('total'));
        $('#mPaid').text('৳ ' + $btn.data('paid'));

        const dueNum = parseFloat(String($btn.data('due')).replace(/,/g,''));
        $('#mDue').text('৳ ' + due)
                  .removeClass('text-danger text-muted')
                  .addClass(dueNum > 0 ? 'text-danger' : 'text-muted');

        if (bank) {
            $('#mBank').text(bank);
            $('#mBankWrap').show();
        } else {
            $('#mBankWrap').hide();
        }

        // Edit link
        $('#mEditBtn').attr('href', `/bandwidth-buy/purchase/${id}/edit`);

        // Populate lines from pre-rendered JS data
        const lines = PURCHASE_LINES[id] || [];
        let grandTotal = 0;

        if (lines.length === 0) {
            $('#linesTableBody').html(`
                <tr>
                    <td colspan="8" class="text-center py-4 text-muted">
                        <i class="fas fa-inbox mr-1"></i> No line items found.
                    </td>
                </tr>`);
            $('#linesTableFoot').hide();
        } else {
            let html = '';
            lines.forEach(function (line, idx) {
                const c = svcColor(line.service);
                html += `
                <tr>
                    <td class="text-center text-muted small pl-4">${idx + 1}</td>
                    <td>
                        <span class="svc-badge"
                              style="background:${c.bg};color:${c.txt};">
                            <i class="fas fa-wifi mr-1"></i>${line.service}
                        </span>
                    </td>
                    <td><i class="fas fa-calendar-alt text-muted mr-1"></i>${line.from_date}</td>
                    <td><i class="fas fa-calendar-alt text-muted mr-1"></i>${line.to_date}</td>
                    <td class="text-right font-weight-bold">${line.qty}</td>
                    <td class="text-right">${line.rate}</td>
                    <td class="text-center">
                        <span class="badge badge-light border">${line.vat}%</span>
                    </td>
                    <td class="text-right font-weight-bold pr-4">${line.total}</td>
                </tr>`;
                grandTotal += parseFloat((line.total || '0').replace(/,/g,''));
            });

            $('#linesTableBody').html(html);
            $('#mGrandTotal').text('৳ ' + grandTotal.toLocaleString('en-US', {minimumFractionDigits:2}));
            $('#linesTableFoot').show();
        }

        $('#linesModal').modal('show');
    });

});
</script>
@stop
