{{-- resources/views/sms/reports.blade.php --}}
@extends('layouts.app')
@section('page_title', 'SMS Reports')
@section('page_content')

{{-- Stats --}}
<div class="row mb-3">
    <div class="col-md-3">
        <div class="info-box bg-success">
            <span class="info-box-icon"><i class="fas fa-paper-plane"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Today Sent</span>
                <span class="info-box-number">{{ $todaySent }}</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="info-box bg-primary">
            <span class="info-box-icon"><i class="fas fa-check-circle"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Total Success</span>
                <span class="info-box-number">{{ number_format($totalSent) }}</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="info-box bg-danger">
            <span class="info-box-icon"><i class="fas fa-times-circle"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Total Failed</span>
                <span class="info-box-number">{{ number_format($totalFailed) }}</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="info-box bg-info">
            <span class="info-box-icon"><i class="fas fa-sms"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Total SMS</span>
                <span class="info-box-number">{{ number_format($totalSent + $totalFailed) }}</span>
            </div>
        </div>
    </div>
</div>

{{-- Filter --}}
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-filter mr-1"></i> Search & Filter</h3>
    </div>
    <div class="card-body">
        <form method="GET">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group mb-0">
                        <label class="small font-weight-bold">Mobile Number</label>
                        <div class="input-group input-group-sm">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-mobile-alt"></i></span>
                            </div>
                            <input type="text" name="mobile" class="form-control"
                                   placeholder="01XXXXXXXXX"
                                   value="{{ request('mobile') }}">
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group mb-0">
                        <label class="small font-weight-bold">Status</label>
                        <select name="status" class="form-control form-control-sm">
                            <option value="">All</option>
                            <option value="sent" {{ request('status') == 'sent' ? 'selected' : '' }}>Success</option>
                            <option value="failed"  {{ request('status') == 'failed'  ? 'selected' : '' }}>Failed</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group mb-0">
                        <label class="small font-weight-bold">Type</label>
                        <select name="type" class="form-control form-control-sm">
                            <option value="">All Types</option>
                            @foreach(\App\Models\SmsLog::TYPES as $key => $label)
                                <option value="{{ $key }}" {{ request('type') == $key ? 'selected' : '' }}>
                                    {{ $label }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group mb-0">
                        <label class="small font-weight-bold">Gateway</label>
                        <select name="gateway" class="form-control form-control-sm">
                            <option value="">All</option>
                            @foreach($gateways as $gw)
                                <option value="{{ $gw }}" {{ request('gateway') == $gw ? 'selected' : '' }}>
                                    {{ $gw }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group mb-0">
                        <label class="small font-weight-bold">Date Range</label>
                        <div class="input-group input-group-sm">
                            <input type="date" name="date_from" class="form-control"
                                   value="{{ request('date_from') }}">
                            <div class="input-group-prepend input-group-append">
                                <span class="input-group-text">→</span>
                            </div>
                            <input type="date" name="date_to" class="form-control"
                                   value="{{ request('date_to') }}">
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-2">
                <button type="submit" class="btn btn-sm btn-primary">
                    <i class="fas fa-search mr-1"></i> Search
                </button>
                <a href="{{ route('sms.reports') }}" class="btn btn-sm btn-secondary ml-1">
                    <i class="fas fa-redo mr-1"></i> Reset
                </a>
                @if(request()->hasAny(['mobile','status','type','gateway','date_from','date_to']))
                    <span class="badge badge-warning ml-2">
                        Filtered: {{ $logs->total() }} results
                    </span>
                @endif
            </div>
        </form>
    </div>
</div>

{{-- SMS Details Table --}}
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">
            <i class="fas fa-list mr-1"></i> SMS Details
        </h3>
        <div>
            <span class="badge badge-success mr-1">
                <i class="fas fa-check mr-1"></i>
                Success: {{ $logs->getCollection()->where('status','sent')->count() }}
            </span>
            <span class="badge badge-danger">
                <i class="fas fa-times mr-1"></i>
                Failed: {{ $logs->getCollection()->where('status','failed')->count() }}
            </span>
        </div>
    </div>
    <div class="card-body p-0">
        <table class="table table-sm table-striped table-hover mb-0">
            <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Mobile</th>
                    <th>Type</th>
                    <th>Gateway</th>
                    <th>Count</th>
                    <th>Message</th>
                    <th>Status</th>
                    <th>Response</th>
                    <th>Date & Time</th>
                </tr>
            </thead>
            <tbody>
                @forelse($logs as $i => $log)
                <tr>
                    <td class="text-muted small">{{ $logs->firstItem() + $i }}</td>
                    <td>
                        <a href="{{ route('sms.reports', ['mobile' => $log->mobile]) }}"
                           class="text-primary">
                            <code>{{ $log->mobile }}</code>
                        </a>
                    </td>
                    <td>
                        <span class="badge badge-info">
                            {{ \App\Models\SmsLog::TYPES[$log->type] ?? $log->type }}
                        </span>
                    </td>
                    <td><small><code>{{ $log->gateway }}</code></small></td>
                    <td>{{$log->count_sms}}</td>
                    <td style="max-width:220px">
                        <a href="javascript:void(0)"
                           class="text-dark view-message"
                           data-message="{{ $log->message }}"
                           data-mobile="{{ $log->mobile }}"
                           data-response="{{ $log->response }}"
                           title="ক্লিক করে সম্পূর্ণ message দেখো">
                            <small>{{ Str::limit($log->message, 55) }}</small>
                        </a>
                    </td>
                    <td>
                        <span class="badge badge-{{ $log->status === 'sent' ? 'success' : 'danger' }}">
                            <i class="fas fa-{{ $log->status === 'sent' ? 'check' : 'times' }} mr-1"></i>
                            {{ $log->status === 'sent' ? 'Sent' : 'Failed' }}
                        </span>
                    </td>
                    <td style="max-width:120px">
                        <a href="javascript:void(0)"
                           class="text-dark view-message"
                           data-message="{{ $log->message }}"
                           data-mobile="{{ $log->mobile }}"
                           data-response="{{ $log->response }}"
                           title="ক্লিক করে সম্পূর্ণ response দেখো">
                            <small class="text-muted">{{ Str::limit($log->response, 25) }}</small>
                        </a>
                    </td>
                    <td>
                        <small>{{ $log->created_at->format('d M Y') }}</small>
                        <br><small class="text-muted">{{ $log->created_at->format('h:i A') }}</small>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8" class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                        SMS Log Empty।
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="card-footer d-flex justify-content-between align-items-center">
        <small class="text-muted">
            Total {{ $logs->total() }}  record — page {{ $logs->currentPage() }}/{{ $logs->lastPage() }}
        </small>
        {{ $logs->withQueryString()->links('pagination::bootstrap-4') }}
    </div>
</div>

{{-- Full Message Modal --}}
<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-sms mr-1"></i> Full Message</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-muted small mb-1">
                    <i class="fas fa-mobile-alt mr-1"></i> <code id="modalMobile"></code>
                </p>
                <label class="font-weight-bold small text-muted mb-1">Message</label>
                <div id="modalMessage" class="mb-3" style="white-space:pre-wrap; word-break:break-word;"></div>

                <label class="font-weight-bold small text-muted mb-1">Gateway Response</label>
                <div id="modalResponse" class="p-2 bg-light rounded border small text-muted"
                     style="white-space:pre-wrap; word-break:break-word;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

@endsection

@push('js')
<script>
document.querySelectorAll('.view-message').forEach(function (el) {
    el.addEventListener('click', function () {
        document.getElementById('modalMobile').textContent   = this.dataset.mobile;
        document.getElementById('modalMessage').textContent  = this.dataset.message;
        document.getElementById('modalResponse').textContent = this.dataset.response || '—';
        $('#messageModal').modal('show');
    });
});
</script>
@endpush
